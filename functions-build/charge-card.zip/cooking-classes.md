---
id: 2
name: Cooking classes
description: A great way to learn delicious things and meet people
price: 20000
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla sodales elit elit, a luctus diam dignissim volutpat. Donec in tortor eros. Ut porttitor sed augue in lacinia. Sed at leo purus. Nunc pharetra nec velit quis ornare. Proin ullamcorper ligula ac ultricies dignissim. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Nam blandit bibendum dui eget maximus. Phasellus gravida odio ut rutrum fermentum. Donec fermentum at metus condimentum volutpat. Curabitur auctor dolor sed maximus rhoncus. Nunc iaculis bibendum felis vitae maximus.

Fusce rutrum nisi felis, in vehicula tellus tincidunt et. Mauris convallis fermentum tellus, eget pellentesque enim consequat id. Pellentesque semper maximus euismod. Praesent consectetur semper aliquet. Sed vel turpis dignissim, laoreet ligula laoreet, ultrices urna. Nulla facilisi. Mauris quis scelerisque sapien. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Sed aliquam vitae est quis maximus. Nunc ultrices felis dolor, vitae posuere purus mollis non. Fusce sed ultrices nibh, ac aliquet odio. Maecenas malesuada nisl eget orci luctus facilisis.

Etiam quis quam id ipsum porttitor auctor eu quis est. Curabitur blandit pellentesque tincidunt. Aliquam erat volutpat. Ut lobortis vitae tortor a venenatis. Nam bibendum, lorem ac laoreet cursus, nisl ligula fringilla lectus, et rutrum ipsum massa vel sem. Nunc est dolor, sagittis eget libero a, sollicitudin efficitur augue. Orci vari.
